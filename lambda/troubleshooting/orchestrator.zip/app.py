"""
トラブルシューティング エージェント Orchestrator Lambda
入力検証、Bedrock Agent呼び出し、結果統合を担当
"""
import json
import uuid
import logging
import os
import re
from typing import Dict, Any, Tuple
from datetime import datetime
import boto3

# ロギング設定
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS クライアント
bedrock_client = boto3.client('bedrock-agent-runtime', 
    region_name=os.environ.get('BEDROCK_REGION', 'us-east-1'))
dynamodb = boto3.resource('dynamodb', region_name=os.environ.get('AWS_REGION', 'us-east-1'))

# 環境変数
AGENT_ID = os.environ.get('AGENT_ID')
AGENT_ALIAS_ID = os.environ.get('AGENT_ALIAS_ID')
SITES_TABLE = os.environ.get('SITES_TABLE', 'sites')

# バリデーション定義
VALIDATION_RULES = {
    'constructionNumber': {
        'required': True,
        'pattern': r'^[A-Za-z0-9]{8}$',
        'message': '工事番号は半角英数8文字で指定してください'
    },
    'troubleDescription': {
        'required': True,
        'min_length': 5,
        'max_length': 2000,
        'message': '不具合情報は5～2000文字で入力してください'
    },
    'model': {
        'required': False,
        'allowed_values': ['KE-LG', 'KM-LD', 'CM-MA', 'ME-CH'],
        'message': '指定されたモデルのみ選択可能です'
    },
    'errorCode': {
        'required': False,
        'pattern': r'^[A-Z0-9]{3}$',
        'message': 'エラーコードは半角英数3文字で指定してください'
    }
}


class ValidationError(Exception):
    """バリデーションエラー"""
    pass


def validate_input(request_body: Dict[str, Any]) -> Dict[str, Any]:
    """
    リクエストの入力検証
    
    Args:
        request_body: リクエストボディ
        
    Returns:
        検証済みのデータ
        
    Raises:
        ValidationError: バリデーション失敗時
    """
    validated = {}
    
    # constructionNumber 検証
    construction_number = request_body.get('constructionNumber', '').strip()
    if not construction_number:
        raise ValidationError(f"工事番号は必須です")
    if not re.match(VALIDATION_RULES['constructionNumber']['pattern'], construction_number):
        raise ValidationError(VALIDATION_RULES['constructionNumber']['message'])
    validated['constructionNumber'] = construction_number
    
    # troubleDescription 検証
    trouble_description = request_body.get('troubleDescription', '').strip()
    if not trouble_description:
        raise ValidationError("不具合情報は必須です")
    if len(trouble_description) < VALIDATION_RULES['troubleDescription']['min_length']:
        raise ValidationError(f"不具合情報は最低{VALIDATION_RULES['troubleDescription']['min_length']}文字以上で入力してください")
    if len(trouble_description) > VALIDATION_RULES['troubleDescription']['max_length']:
        raise ValidationError(f"不具合情報は最大{VALIDATION_RULES['troubleDescription']['max_length']}文字以下で入力してください")
    validated['troubleDescription'] = trouble_description
    
    # model 検証（オプション）
    if 'model' in request_body and request_body['model']:
        model = request_body['model'].strip()
        if model not in VALIDATION_RULES['model']['allowed_values']:
            raise ValidationError(VALIDATION_RULES['model']['message'])
        validated['model'] = model
    
    # classification 検証（オプション）
    if 'classification' in request_body and request_body['classification']:
        classification = request_body['classification'].strip()
        if classification not in ['機械的', '電気的']:
            raise ValidationError("分類は「機械的」または「電気的」で指定してください")
        validated['classification'] = classification
    
    # errorCode 検証（オプション）
    if 'errorCode' in request_body and request_body['errorCode']:
        error_code = request_body['errorCode'].strip().upper()
        if not re.match(VALIDATION_RULES['errorCode']['pattern'], error_code):
            raise ValidationError(VALIDATION_RULES['errorCode']['message'])
        validated['errorCode'] = error_code
    
    # troubleOccurredAt 検証（オプション、ISO 8601形式）
    if 'troubleOccurredAt' in request_body and request_body['troubleOccurredAt']:
        try:
            datetime.fromisoformat(request_body['troubleOccurredAt'].replace('Z', '+00:00'))
            validated['troubleOccurredAt'] = request_body['troubleOccurredAt']
        except ValueError:
            raise ValidationError("troubleOccurredAtはISO 8601形式で指定してください（例：2026-01-26T19:00:00Z）")
    
    return validated


def get_site_info(construction_number: str) -> Dict[str, Any]:
    """
    DynamoDB sites テーブルから現場情報を取得
    
    Args:
        construction_number: 工事番号
        
    Returns:
        現場情報
    """
    try:
        table = dynamodb.Table(SITES_TABLE)
        response = table.get_item(Key={'constructionNumber': construction_number})
        
        if 'Item' not in response:
            logger.warning(f"Site not found: {construction_number}")
            return {
                'constructionNumber': construction_number,
                'siteName': 'Unknown',
                'installedEquipment': []
            }
        
        return response['Item']
    except Exception as e:
        logger.error(f"Error fetching site info: {str(e)}")
        raise


def format_agent_input(validated_data: Dict[str, Any], site_info: Dict[str, Any]) -> str:
    """
    Bedrock Agent用のプロンプトを生成
    
    Args:
        validated_data: 検証済みの入力データ
        site_info: 現場情報
        
    Returns:
        エージェント用プロンプト
    """
    equipment_str = ""
    if site_info.get('installedEquipment'):
        for eq in site_info['installedEquipment']:
            equipment_str += f"  - 機種: {eq.get('model', 'N/A')}, 制御システム: {eq.get('controlSystem', 'N/A')}\n"
    
    prompt = f"""
【現場情報】
工事番号: {site_info['constructionNumber']}
現場名: {site_info.get('siteName', 'N/A')}
設置機器:
{equipment_str or '  情報なし'}

【トラブル情報】
不具合内容: {validated_data['troubleDescription']}
"""
    
    if 'model' in validated_data:
        prompt += f"対象機種: {validated_data['model']}\n"
    
    if 'classification' in validated_data:
        prompt += f"分類: {validated_data['classification']}\n"
    
    if 'errorCode' in validated_data:
        prompt += f"エラーコード: {validated_data['errorCode']}\n"
    
    if 'troubleOccurredAt' in validated_data:
        prompt += f"発生時刻: {validated_data['troubleOccurredAt']}\n"
    
    prompt += """
【実行内容】
1. DynamoDB を検索して現場の設置機器・過去のトラブル事例を確認
2. Knowledge Base から該当する機種のトラブルシュートマニュアルを検索
3. Knowledge Base から詳細な技術資料（C資料）を検索
4. 以上の情報をもとに原因候補を5件推定し、確率とともに提示
5. 段階的な対処方法を提案
6. 必要に応じてエスカレーション判定

【出力形式】
JSON形式で以下を含む：
- summary: 300文字以内
- estimatedCause: 推定原因
- confidence: 信頼度（0.0-1.0）
- possibleCauses: [{rank, cause, probability, evidence, references}]
- solutions: [{step, title, action, caution, estimatedTime, requiredTools}]
- escalation: {required, reason}
"""
    return prompt


def invoke_agent(agent_input: str) -> Dict[str, Any]:
    """
    Bedrock Agent Manager を呼び出し
    
    Args:
        agent_input: エージェント用入力テキスト
        
    Returns:
        エージェントレスポンス
        
    Raises:
        Exception: API呼び出し失敗時
    """
    session_id = str(uuid.uuid4())
    logger.info(f"Invoking agent with session: {session_id}")
    logger.info(f"Debug: Agent ID = {AGENT_ID}")
    logger.info(f"Debug: Agent Alias ID = {AGENT_ALIAS_ID}")
    logger.info(f"Debug: Bedrock Region = {os.environ.get('BEDROCK_REGION')}")
    logger.info(f"Debug: Bedrock Client Region = {bedrock_client.meta.region_name}")
    
    try:
        response = bedrock_client.invoke_agent(
            agentId=AGENT_ID,
            agentAliasId=AGENT_ALIAS_ID,
            sessionId=session_id,
            inputText=agent_input
        )
        
        # レスポンスストリームを処理
        result_text = ""
        if 'completion' in response:
            for event in response['completion']:
                if 'chunk' in event:
                    chunk = event['chunk']
                    if 'bytes' in chunk:
                        result_text += chunk['bytes'].decode('utf-8')
        
        logger.info(f"Agent response received (length: {len(result_text)})")
        return {
            'sessionId': session_id,
            'response': result_text
        }
        
    except Exception as e:
        logger.error(f"Agent invocation error: {str(e)}")
        raise


def parse_agent_response(agent_response: Dict[str, Any]) -> Dict[str, Any]:
    """
    Bedrock Agent レスポンスをパース
    
    Args:
        agent_response: エージェントレスポンス
        
    Returns:
        解析済みレスポンス
    """
    try:
        response_text = agent_response.get('response', '')
        
        # JSON抽出を試みる
        json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
        if json_match:
            analysis = json.loads(json_match.group())
        else:
            # JSONが見つからない場合は応答テキストそのものを使用
            analysis = {
                'summary': response_text[:300],
                'estimatedCause': response_text,
                'confidence': 0.0
            }
        
        return analysis
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parse error: {str(e)}")
        return {
            'summary': 'レスポンスのパースに失敗しました',
            'estimatedCause': agent_response.get('response', ''),
            'confidence': 0.0,
            'error': 'PARSE_ERROR'
        }


def format_response(analysis_id: str, request_data: Dict[str, Any], 
                   site_info: Dict[str, Any], analysis: Dict[str, Any]) -> Dict[str, Any]:
    """
    最終的なレスポンスを生成
    
    Args:
        analysis_id: 分析ID
        request_data: リクエストデータ
        site_info: 現場情報
        analysis: 分析結果
        
    Returns:
        レスポンス
    """
    return {
        'analysisId': analysis_id,
        'constructionNumber': request_data['constructionNumber'],
        'siteName': site_info.get('siteName', 'Unknown'),
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'analysis': {
            'summary': analysis.get('summary', ''),
            'estimatedCause': analysis.get('estimatedCause', ''),
            'confidence': analysis.get('confidence', 0.0)
        },
        'possibleCauses': analysis.get('possibleCauses', []),
        'solutions': analysis.get('solutions', []),
        'escalation': analysis.get('escalation', {'required': False})
    }


def error_response(status_code: int, message: str) -> Dict[str, Any]:
    """
    エラーレスポンスを生成
    
    Args:
        status_code: HTTPステータスコード
        message: エラーメッセージ
        
    Returns:
        エラーレスポンス
    """
    return {
        'statusCode': status_code,
        'body': json.dumps({
            'error': 'ERROR',
            'message': message,
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }, ensure_ascii=False),
        'headers': {'Content-Type': 'application/json; charset=utf-8'}
    }


def format_orchestration_response(status_code, body_text):
    """
    Bedrock Agent カスタムオーケストレーション用レスポンスを生成
    
    Args:
        status_code: HTTPステータスコード
        body_text: レスポンステキスト
        
    Returns:
        Bedrock Agent 互換のレスポンス JSON
    """
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": "troubleshooting-orchestrator",
            "apiPath": "/analyze",
            "httpMethod": "POST",
            "httpStatusCode": status_code,
            "responseBody": {
                "TEXT": {
                    "body": body_text
                }
            }
        }
    }


def lambda_handler(event, context):
    """
    Orchestrator Lambda メインハンドラー（カスタムオーケストレーション対応）
    
    Args:
        event: Lambda イベント
        context: Lambda コンテキスト
        
    Returns:
        Bedrock Agent カスタムオーケストレーション互換のレスポンス
    """
    logger.info(f"Request received: {json.dumps(event)}")
    
    try:
        # 1. リクエスト解析
        # テストイベント用（直接 JSON）と API Gateway イベント用（body に JSON文字列）の両対応
        if isinstance(event, dict) and 'body' in event:
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        else:
            body = event
        
        # 2. 入力検証
        validated_data = validate_input(body)
        logger.info(f"Validation passed: {validated_data['constructionNumber']}")
        
        # 3. 現場情報取得
        site_info = get_site_info(validated_data['constructionNumber'])
        
        # 4. エージェント用プロンプト生成
        agent_input = format_agent_input(validated_data, site_info)
        logger.info("Agent input formatted")
        
        # 5. Bedrock Agent Manager 呼び出し
        agent_response = invoke_agent(agent_input)
        
        # 6. レスポンス解析
        analysis = parse_agent_response(agent_response)
        
        # 7. 最終レスポンス生成
        analysis_id = str(uuid.uuid4())
        result = format_response(analysis_id, validated_data, site_info, analysis)
        
        logger.info(f"Analysis completed: {analysis_id}")
        
        # 8. カスタムオーケストレーション形式でレスポンス
        response_text = json.dumps(result, ensure_ascii=False, indent=2)
        return format_orchestration_response(200, response_text)
        
    except ValidationError as e:
        logger.error(f"Validation error: {str(e)}")
        error_msg = f"入力検証エラー: {str(e)}"
        return format_orchestration_response(400, error_msg)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        error_msg = f"分析処理中にエラーが発生しました: {str(e)}"
        return format_orchestration_response(500, error_msg)
