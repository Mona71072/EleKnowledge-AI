import json
import boto3
from botocore.exceptions import ClientError

# 環境変数取得
def get_secret(secret_name: str):
    secrets_client = boto3.client("secretsmanager")
    try:
        response = secrets_client.get_secret_value(SecretId=secret_name)
        return json.loads(response["SecretString"])
    except ClientError as e:
        print(f"[ローカルテスト] Secrets Managerエラー: {e} - ダミー値を使用")
        return {
            "AGENT_ID": "D6FAGLJPPO",
            "AGENT_ALIAS_ID": "WBXLCRHOCD"
        }

# 機密情報取得
SECRET_ARN = "arn:aws:secretsmanager:us-east-1:423623870147:secret:EleKnowledgeAI/BedrockAgentConfig-8sBN5B"
secrets = get_secret(SECRET_ARN)
BEDROCK_AGENT_ID = secrets["AGENT_ID"]
BEDROCK_AGENT_ALIAS_ID = secrets["AGENT_ALIAS_ID"]

# クライアント初期化
# クライアント初期化
bedrock_agent_runtime = boto3.client("bedrock-agent-runtime")

def lambda_handler(event, context):
    """
    トラブルシューティングスモールオーケストレーター
    DB検索アクショングループのみを起動
    """
    try:
        # ユーザー入力取得
        user_query = event["queryString"]
        session_id = event["sessionId"]
        
        # Bedrock Agent起動
        response = bedrock_agent_runtime.invoke_agent(
            agentId=BEDROCK_AGENT_ID,
            agentAliasId=BEDROCK_AGENT_ALIAS_ID,
            sessionId=session_id,
            inputText=user_query,
            enableTrace=True
        )
        
        # レスポンス処理
        final_response = process_agent_response(response)
        
        return {
            'statusCode': 200,
            'body': json.dumps(final_response)
        }
    
    except ClientError as e:
        print(f"Bedrock APIエラー: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({"error": "内部サーバーエラー"})
        }

def process_agent_response(response):
    """
    Agentからのレスポンスを整形
    """
    # SECURITY: 機密情報が含まれないか確認
    if "error" in response:
        return {"status": "error", "message": response["error"]}
    
    # アクショングループ結果抽出
    action_results = []
    for event in response["completion"]:
        if event["eventType"] == "ACTION_GROUP_INVOCATION_SUCCEEDED":
            action_results.append(event["actionGroupInvocationOutput"])
    
    return {
        "status": "success",
        "analysis": "DB検索結果を取得しました",
        "data": action_results
    }

# テスト用エントリポイント
if __name__ == "__main__":
    test_event = {
        "queryString": "現場番号1234のトラブルシューティング",
        "sessionId": "test-session-001"
    }
    print(lambda_handler(test_event, None))